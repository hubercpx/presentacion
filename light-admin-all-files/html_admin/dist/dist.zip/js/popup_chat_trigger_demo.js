$(function(){
  $('.floated-chat-w').toggleClass('active');
});

